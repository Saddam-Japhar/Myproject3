import React, { Component } from "react";
import { withRouter } from "react-router-dom";
// import LogInCredentials from "./LogInCredentials.json";

class Form extends Component {
  state = {
    name: "",
    pass: ""
  };
  OnformSubmit = async e => {
    e.preventDefault();
    const res_search = await fetch("http://localhost:4000/computerOps/LogIN", {
      method: "post",
      header: {
        Accept: "application/json",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        name: this.state.name.trim().toString(),
        pass: this.state.pass.trim().toString()
      })
    });
    const json = await res_search.json();
    console.log(json);
    if (json.data === true) {
      this.props.toggle(false);
    } else {
      alert("Username or Password is Incorrect!");
    }
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
  render() {
    return (
      <div className="container mt-3" style={{ height: 650, width: 350 }}>
        <div className="card bg-dark card-form text-center">
          <div className="card-body">
            <h3 className="text-white">Central Access Management</h3>
            <form onSubmit={this.OnformSubmit}>
              <div className="form-group text-white">
                Username
                <input
                  onChange={this.handleChange}
                  type="text"
                  id="name"
                  name="name"
                  value={this.state.name}
                  className="form-control"
                ></input>
                <br />
                Password
                <input
                  onChange={this.handleChange}
                  type="password"
                  id="pass"
                  name="pass"
                  value={this.state.pass}
                  className="form-control"
                />
                <br />
                <button className="btn btn-success btn-lg btn-block">
                  LogIn
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default Form;
