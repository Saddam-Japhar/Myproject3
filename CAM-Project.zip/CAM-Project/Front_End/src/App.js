import React from "react";
import Navbarcatalina from "./Component/Navbarcatalina";
import MainSection from "./Component/MainSection";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Database from "./Component/DB/Database";
import Cameo from "./Component/ComputerOperation/Cameo";
import Wind from "./Component/Wind";
import Form from "./Form.js";

class App extends React.Component {
  state = {
    users: [],
    Login: true
  };
  // componentDidMount() {
  //   this.getUsers();
  // }
  // getUsers = (name, email) => {
  //   fetch("http://localhost:4000/database")
  //     .then(response => response.json())
  //     .then(({ data }) => {
  //       console.log(data);
  //     });
  //   // .then(response => this.setState({ users: response.data.recordsets }))
  //   // .catch(err => console.error(err));
  // };

  // Async await to fetch data from database
  getUsers = async () => {
    const response = await fetch("http://localhost:4000/database");
    const resp = await response.json();
    console.log(resp);
    this.setState({ users: resp.data.recordset });
  };
  toggle = value => {
    this.setState({ Login: value });
  };

  render() {
    // const { users } = this.state;

    let links = [
      { label1: "Window", link: "/window" },
      { label1: "Database", link: "/DB" },
      { label1: "Linux", link: "/linux" },
      { label1: "Network", link: "/Network" },
      { label1: "Computer Operations", link: "/computer" }
    ];

    if (this.state.Login === true) {
      return <Form toggle={this.toggle} />;
    } else {
      return (
        <BrowserRouter>
          <div>
            <Navbarcatalina links={links} />
            <Switch>
              <Route path="/" exact component={MainSection} />z
              <Route path="/window">
                <Wind data="Window Access Management" />
              </Route>
              <Route path="/DB">
                <Database
                  data="Database Access Management"
                  dbdata={this.state.users}
                  retrieveData={this.getUsers}
                />
              </Route>
              <Route path="/linux">
                <Wind data="Linux Access Management" />
              </Route>
              <Route path="/network">
                <Wind data="Network Access Management" />
              </Route>
              <Route path="/computer">
                <Cameo data="Computer Operations Access Management" />
              </Route>
              {/* <Route path="/database/search" component={Search} /> */}
            </Switch>
          </div>
        </BrowserRouter>
      );
    }
  }
}
export default App;
