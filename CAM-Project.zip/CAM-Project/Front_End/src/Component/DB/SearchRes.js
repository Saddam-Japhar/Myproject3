import React, { Component } from "react";

export default class SearchRes extends Component {
  state = {
    gain_value: []
  };
  renderTableData() {
    return this.props.val.map(
      ({ name, create_date, modify_date, type_desc, default_schema_name }) => {
        //  const { id, name, age, email } = student //destructuring
        return (
          <tr>
            <td>{name}</td>
            <td>{create_date}</td>
            <td>{modify_date}</td>
            <td>{type_desc}</td>
            {/* <td>{default_schema_name}</td> */}
          </tr>
        );
      }
    );
  }
  render() {
    // const [
    //   { name, create_date, type_desc, default_schema_name }
    // ] = this.state.gain_value;

    return (
      <div>
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Created Date</th>
              <th scope="col">Modify Date</th>
              <th scope="col">Type</th>
              {/* <th scope="col">Default Schema</th> */}
            </tr>
          </thead>
          <tbody>{this.renderTableData()}</tbody>
        </table>
      </div>
    );
  }
}
