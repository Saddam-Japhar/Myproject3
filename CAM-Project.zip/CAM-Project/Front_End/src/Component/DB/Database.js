import React, { Component } from "react";
import "../Wind.css";
import "../../../node_modules/font-awesome/css/font-awesome.min.css";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { Link } from "react-router-dom";
import CreateUserLogIn from "./CreateUserLogIn";
import Search from "./Search.js";
class Database extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className=" wind container">
          <h1 className="mb-5">{this.props.data}</h1>

          <div class="card text-center">
            <div class="card-header bg-secondary">
              <ul class="nav nav-pills navbar-dark  card-header-pills">
                <li class="nav-item">
                  <Link to="/DB" class="nav-link text-light">
                    Create LogIN
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/DB/Search" class="nav-link text-light">
                    Search
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <div>
                <Switch>
                  <Route exact path="/DB">
                    <CreateUserLogIn />
                  </Route>
                  <Route exact path="/DB/Search">
                    <Search prData={this.props.retrieveData} />
                  </Route>
                </Switch>
              </div>
            </div>
          </div>
          <div>
            <div>
              {this.props.dbdata.map(({ id, name, email }) => {
                return (
                  <div key={id}>
                    <p>Name:{name}</p>
                    <p>Email:{email}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </BrowserRouter>
    );
  }
}

export default Database;
