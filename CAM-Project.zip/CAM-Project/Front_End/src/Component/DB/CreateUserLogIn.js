import React from "react";
import "../Wind.css";
import "../../../node_modules/font-awesome/css/font-awesome.min.css";

class CreateUserLogIn extends React.Component {
  state = {
    LogIn: "",
    Password: "",
    UserName: "",
    Database: "",
    loading: false
  };

  onInputChange = event => {
    this.setState({ [event.target.name]: event.target.value });

    // console.log(this.state.name);
  };

  onFormSubmit = async event => {
    event.preventDefault();
    this.setState({ loading: true });
    console.log(this.state);
    const resp = await fetch("http://localhost:4000/database", {
      method: "post",

      header: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        LogIn: this.state.LogIn,
        Password: this.state.Password,
        UserName: this.state.UserName,
        Database: this.state.Database
      })
    });
    const json = await resp.json();
    if (json.data === 0) {
      console.log("empty");
    } else {
      console.log(json.data);
      // this.props.prData();
    }

    this.setState({ loading: false });
  };

  render() {
    const { loading } = this.state;
    return (
      <div class="card-body">
        <h5 class="card-title">Create database LogIn and User</h5>
        <p class="card-text">
          Kindly select Authentication type from the drop down
        </p>
        <form onSubmit={this.onFormSubmit} className="form-group">
          <div className="form-row align-items-center">
            <div className="col-sm-4">
              <label class="sr-only" htmlFor="LogIN">
                LogIn
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">LogIn</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="LogIn"
                  // ref={ref => {
                  //   this.name = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.LogIn}
                  id="LogIN"
                  placeholder="LogIn"
                />
              </div>
            </div>
            <div className="col-sm-4">
              <label class="sr-only" for="Password">
                Password
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">Pswd</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="Password"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.Password}
                  id="email"
                  placeholder="Password"
                />
              </div>
            </div>
            <div className="col-sm-2 mb-1">
              <select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                <option selected>Choose...</option>
                <option value="1">Window Auth</option>
                <option value="2">SQL Auth</option>
              </select>
            </div>
          </div>
          <div className="form-row align-items-center">
            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="User">
                User
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">User</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="UserName"
                  // ref={ref => {
                  //   this.name = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.UserName}
                  id="UserName"
                  placeholder="UserName"
                />
              </div>
            </div>
            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="Database">
                Database
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">Database</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="Database"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.Database}
                  id="email"
                  placeholder="Database"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            // onClick={this.proceed}
            className="btn btn-large btn-block btn-primary mt-5"
            id="butn"
            disabled={loading}
          >
            {loading && <i className="fa fa-refresh fa-spin" />}
            {loading && <span>Processing your Request</span>}
            {!loading && <span>Proceed</span>}
          </button>
        </form>
      </div>
    );
  }
}

export default CreateUserLogIn;
