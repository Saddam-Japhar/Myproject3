import React, { Component } from "react";
import "../Wind.css";
import "../../../node_modules/font-awesome/css/font-awesome.min.css";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { Link } from "react-router-dom";
// import CreateUserLogIn from "./CreateUserLogIn";
import Search from "./Search.js";
import CellEval from "./CellEval.js";
import Activedir from "./Activedir";
class Database extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className=" wind container">
          <h1 className="mb-5">{this.props.data}</h1>

          <div class="card text-center">
            <div class="card-header bg-secondary">
              <ul class="nav nav-pills navbar-dark  card-header-pills">
                <li class="nav-item">
                  <Link to="/computer" class="nav-link text-light">
                    CellEval
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/computer/Search" class="nav-link text-light">
                    CameoSearch
                  </Link>
                </li>
                <li class="nav-item">
                  <Link
                    to="/computer/ActiveDirectory"
                    class="nav-link text-light"
                  >
                    Active Directory
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <div>
                <Switch>
                  {/* <Route exact path="/DB">
                    <CreateUserLogIn />
                  </Route> */}
                  <Route exact path="/computer/">
                    <CellEval />
                  </Route>
                  <Route exact path="/computer/Search">
                    <Search prData={this.props.retrieveData} />
                  </Route>

                  <Route exact path="/computer/Activedirectory">
                    <Activedir />
                  </Route>
                </Switch>
              </div>
            </div>
          </div>
          <div></div>
        </div>
      </BrowserRouter>
    );
  }
}

export default Database;
