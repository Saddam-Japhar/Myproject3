import React, { Component } from "react";
import UserForm from "./UserForm";
export default class ActiveRes extends Component {
  constructor(props) {
    super(props);
    this.state = {
      gain_value: "",
      groupSelect: false,
      selectedValue: []
    };
  }

  clickHandler = event => {
    let value = event.target.value;
    let selected = this.state.selectedValue;
    if (selected.includes(value)) {
      selected.splice(selected.indexOf(value), 1);
    } else {
      selected.push(event.target.value);
    }
    this.setState({ selectedValue: selected });
  };

  checkSelected = value => {
    if (this.state.selectedValue.includes(value)) {
      return true;
    } else {
      return false;
    }
  };

  // renderFormData() {
  //   return (
  //     <div>
  //       <UserForm />
  //     </div>
  //   );
  // }
  renderRestrictedGroup() {
    return (
      <div>
        
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>ARTISIAN_ADMIN</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>AMEX Cardholders (per Hope O�Kelley)</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>CARETeam</td>
        </tr>
<tr>
          <td style={{ fontSize: 14, height: "3px" }}>CMC Directors & Above (unless title is director or senior director)</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>CMC Managers (unless new person is manager or above)</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>CMC VPS US ONLY (unless new person is a VP)</td>
        </tr>
<tr>
          <td style={{ fontSize: 14, height: "3px" }}>Citrix (All, NO exceptions)</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>Clarity Users (per Christie Juckett)</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>Domain Admin</td>
        </tr>
<tr>
          <td style={{ fontSize: 14, height: "3px" }}>Fit Fin</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>Green Team</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>Infra (any group with "Infra" in it unless specifically requested</td>
        </tr>
<tr>
          <td style={{ fontSize: 14, height: "3px" }}>Media Relations (per Moira Hinson)</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>Any MEDIA_PLTFRM_xx_Admin (see Media Platform Access  for more details)</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>MetaFrame (All MetaFrame, NO exceptions)</td>
        </tr>

<tr>
          <td style={{ fontSize: 14, height: "3px" }}>MXP Team</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>MXP Scrum Team</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>MXP</td>
        </tr>

<tr>
          <td style={{ fontSize: 14, height: "3px" }}>MXP UST Team</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>PVCS Tracker Users</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>PVCS VM Users</td>
        </tr>

<tr>
          <td style={{ fontSize: 14, height: "3px" }}>SLT</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>TFS - all TFS groups</td>
        </tr>
        <tr>
          <td style={{ fontSize: 14, height: "3px" }}>Running Team runningteam@catalina.com.</td>
        </tr>


      </div>
    );
  }

  renderTableData() {
   
   
   
    return this.props.val.map(({GroupName}) => {
      let checked = this.checkSelected(GroupName);
      return (
        <tr>
          <td style={{ fontSize: 12, height: "3px" }}>
            <input
              type="checkbox"
              onChange={this.clickHandler}
              name={GroupName}
              checked={checked}
              value={GroupName}
              className="form-check-input "
            />
          </td>

          <td style={{ fontSize: 12, height: "3px" }}>{GroupName}</td>
        </tr>
      );
    });
  }
  toggleCheck = () => {
    if (this.state.groupSelect) {
      this.setState({ selectedValue: [], groupSelect: false });
    } else {
      let data = this.props.val.map(obj => obj.GroupName);
      this.setState({ selectedValue: data, groupSelect: true });
    }
  };

  render() {
   
    return (
      <div>
        <div class="row">
          <div className="col-sm-7">
            <table className="table table-dark">
              <thead>
                <tr>
                  <th scope="col" className=" pl-5 pb-5">
                    <input
                      type="checkbox"
                      onClick={this.toggleCheck}
                      style={{ alignItems: "center" }}
                      className="form-check-input"
                    />{" "}
                  </th>

                  <th scope="col" style={{ fontSize: "14px" }}>
                    Group Name
                  </th>
                </tr>
              </thead>
              <tbody>{this.renderTableData()}</tbody>
            </table>
          </div>
          <div className="col-sm-5">
            <table className="table table-danger">
              <thead>
                <tr>
                  <th scope="col" style={{ fontSize: "14px", height: 60 }}>
                    Restricted Group
                  </th>
                </tr>
              </thead>
              <tbody>{this.renderRestrictedGroup()}</tbody>
            </table>
          </div>
        </div>
        <div>
          <UserForm selectedvalue={this.state.selectedValue} />
        </div>
      </div>
    );
  }
}
