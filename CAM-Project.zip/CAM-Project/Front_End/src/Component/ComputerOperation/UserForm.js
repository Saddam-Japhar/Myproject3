import React from "react";
import "../Wind.css";
import "../../../node_modules/font-awesome/css/font-awesome.min.css";
import Credentials from "./Credentials";

class UserForm extends React.Component {
  state = {
    FirstName: "",
    LastName: "",
    FullName: "",
    LogonName: "",
    MirrId: "",
    EmpId: "",
    Title: "",
    loading: false,
    password:"",
    Description:"",
    DisplayName:"",
    Initials:""

  };

  onInputChange = event => {
    this.setState({ [event.target.name]: event.target.value });

    // console.log(this.state.name);
  };

  // getInfo = async () => {
  //   const response = await fetch(
  //     "http://localhost:4000/computerOps/AccountCreation"
  //   );
  //   const resp = await response.json();
  //   console.log(resp);
  //   // this.setState({ users: resp.data.recordset });
  // };

  onFormSubmit = async event => {
    event.preventDefault();
    this.setState({ loading: true });
    console.log(this.state);
    const resp = await fetch(
      "http://localhost:4000/computerOps/AccountCreation",
      {
        method: "post",

        header: {
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          FirstName: this.state.FirstName,
          LastName: this.state.LastName,
          LogonName: this.state.LogonName.trim().toString(),
          MirrId: this.state.MirrId,
          EmpId: this.state.EmpId,
          Title: this.state.Title,
          Description:this.state.Description,
          DisplayName:this.state.DisplayName,
          Initials:this.state.Initials,
          selectedvalue: this.props.selectedvalue
        })
      }
    );
    const json = await resp.json();
    console.log(json);
    
    this.setState({password:json.pass})

    this.setState({ loading: false });
    
  };

  render() {
    const { loading } = this.state;
    return (
      <div class="card-body">
        <h5 class="card-title">Active Directory Account Creation</h5>
        {/* <p class="card-text">
          Kindly select Authentication type from the drop down
        </p> */}
        <form onSubmit={this.onFormSubmit} className="form-group">
          <div className="form-row align-items-center">
            <div className="col-sm-5">
              <label class="sr-only" htmlFor="FirstName">
                FirstName
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">FirstName</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="FirstName"
                  // ref={ref => {
                  //   this.name = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.FirstName}
                  id="FirstName"
                  placeholder="FirstName"
                />
              </div>
            </div>
            <div className="col-sm-5">
              <label class="sr-only" for="LastName">
                LastName
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">LastName</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="LastName"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.LastName}
                  id="LastName"
                  placeholder="LastName"
                />
              </div>
            </div>
          </div>
          <div className="form-row align-items-center">
            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="User">
                User
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">LogonName</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="LogonName"
                  // ref={ref => {
                  //   this.name = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.UserName}
                  id="LogonName"
                  placeholder="User LogonName"
                />
              </div>
            </div>
            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="MirrId">
                MirrId
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">Mirror Id</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="MirrId"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.MirrId}
                  id="MirrId"
                  placeholder="Mirror ID"
                />
              </div>
            </div>
            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="EmpId">
                EmpId
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">EmpId</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="EmpId"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.EmpId}
                  id="EmpId"
                  placeholder="Employee Id"
                />
              </div>
            </div>
            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="Title">
                Title
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">Title</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="Title"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.Title}
                  id="EmpId"
                  placeholder="Job Title"
                />
              </div>
            </div>
            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="Description">
              Description
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">Description</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="Description"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.Description}
                  id="Description"
                  placeholder="Description"
                />
              </div>
            </div>

            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="DisplayName">
              DisplayName
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">DisplayName</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="DisplayName"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.DisplayName}
                  id="DisplayName"
                  placeholder="DisplayName"
                />
              </div>
            </div>

            <div className="col-sm-5 mt-3">
              <label class="sr-only" for="Initials">
              Initials
              </label>
              <div class="input-group ">
                <div class="input-group-prepend">
                  <div class="input-group-text">Initials</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  name="Initials"
                  // ref={ref => {
                  //   this.email = ref;
                  // }}
                  onChange={this.onInputChange}
                  value={this.state.Initials}
                  id="Initials"
                  placeholder="Initials"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            // onClick={this.proceed}
            className="btn btn-large btn-block btn-primary mt-5"
            id="butn"
            disabled={loading}
          >
            {loading && <i className="fa fa-refresh fa-spin" />}
            {loading && <span>Processing your Request</span>}
            {!loading && <span>Proceed</span>}
          </button>
        </form>
        <Credentials val={this.state} pass={this.state.password}/>
      </div>
    );
  }
}

export default UserForm;
