import React, { Component } from "react";
import "../../../node_modules/font-awesome/css/font-awesome.min.css";
import CameoResult from "./CameoResult";

class CellEval extends Component {
  state = {
    selectValue: "sjaphar",
    isLoading: false,
    received_value: []
  };
  handleChange = event => {
    this.setState({ selectValue: event.target.value });
  };

  onSubmit = async event => {
    event.preventDefault();
    this.setState({ isLoading: true });
    const res_search = await fetch("http://localhost:4000/computerOps/search", {
      method: "post",
      header: {
        Accept: "application/json",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        value: this.state.selectValue
      })
    });
    const json = await res_search.json();

    if (json.data.length === 0) {
      console.log(
        `${this.state.selectValue} is not the user of CamDB_test database `
      );
    } else {
      console.log(json.data);
    }
    this.setState({ received_value: json.data });
    console.log(this.state.received_value);
    // await this.props.prData();
    // console.log(this.state.loading);
    this.setState({ isLoading: false });
  };
  render() {
    const { isLoading } = this.state;
    return (
      <div className="container">
        <form onSubmit={this.onSubmit} className="form-group">
          <div className="form align-items-center">
            <div>
              <select
                value={this.state.selectValue}
                onChange={this.handleChange}
                className="custom-select mr-sm-2 mt-3 mb-5"
              >
                <option value="Choose...">Choose..</option>
                <option value="us">USA</option>
                <option value="jp">JAPAN</option>
                <option value="it">ITALY</option>
                <option value="fr">FRANCE</option>
                <option value="de">GERMANY</option>
              </select>
            </div>
          </div>
          <button
            type="submit"
            onClick={this.onSubmit}
            className="btn btn-large btn-block btn-primary mt-5"
            id="butn"
            disabled={isLoading}
          >
            {isLoading && <i className="fa fa-refresh fa-spin" />}
            {isLoading && <span>Please wait Looking into the database</span>}
            {!isLoading && <span>Find</span>}
          </button>
        </form>
        <CameoResult val={this.state.received_value} />
      </div>
    );
  }
}

export default CellEval;
