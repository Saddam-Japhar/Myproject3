import React, { Component } from "react";

export default class SearchRes extends Component {
  state = {
    gain_value: []
  };
  renderTableData() {
    return this.props.val.map(
      ({ current_country_code, display_nm, net_id, user_email, user_nbr }) => {
        //  const { id, name, age, email } = student //destructuring
        return (
          <tr>
            <td>{current_country_code}</td>
            <td>{display_nm}</td>
            <td>{net_id}</td>
            <td>{user_email}</td>
            <td>{user_nbr}</td>
            {/* <td>{user_nm}</td> */}
          </tr>
        );
      }
    );
  }
  render() {
    // const [
    //   { name, create_date, type_desc, default_schema_name }
    // ] = this.state.gain_value;

    return (
      <div>
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">Country</th>
              <th scope="col">Name</th>

              <th scope="col">Net ID</th>
              <th scope="col">Email</th>
              <th scope="col">NBR</th>
              {/* <th scope="col"></th> */}
            </tr>
          </thead>
          <tbody>{this.renderTableData()}</tbody>
        </table>
      </div>
    );
  }
}
