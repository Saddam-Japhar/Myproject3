import React, { Component } from "react";

export default class SearchRes extends Component {
  state = {
    gain_value: []
  };
  renderTableData() {
console.log(typeof(this.props.val.map))
    return this.props.val.map(
      ({ cmpgn_nbr, cmpgn_typ, cell_nbr, current_state, queued_tms }) => {
        //  const { id, name, age, email } = student //destructuring
        return (
          <tr>
            <td>{cmpgn_nbr}</td>
            <td>{cmpgn_typ}</td>
            <td>{cell_nbr}</td>
            <td>{current_state}</td>
            <td>{queued_tms}</td>
            {/* <td>{user_nm}</td> */}
          </tr>
        );
      }
    );
  }
  render() {
    // const [
    //   { name, create_date, type_desc, default_schema_name }
    // ] = this.state.gain_value;

    return (
      <div>
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">cmpgn_number</th>
              <th scope="col">cmpgn_type</th>

              <th scope="col">cell_nbr</th>
              <th scope="col">current_state</th>
              <th scope="col">queued_tms</th>
              {/* <th scope="col"></th> */}
            </tr>
          </thead>
          <tbody>{this.renderTableData()}</tbody>
        </table>
      </div>
    );
  }
}
