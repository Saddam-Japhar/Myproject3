import React, { Component } from "react";

export default class Credentials extends Component {
  state = {
    gain_value: []
  };
  renderTableData() {
//console.log(typeof(this.props.val.map))
 
  const {LogonName,MirrId,EmpId}=this.props.val
  
  return (
          <tr>
            <td>{LogonName}</td>
            <td>{EmpId}</td>
            <td>{MirrId}</td>
            <td>{this.props.pass}</td>
            
            
            {/* <td>{user_nm}</td> */}
          </tr>
        );
   
  }
  render() {
    // const [
    //   { name, create_date, type_desc, default_schema_name }
    // ] = this.state.gain_value;

    return (
      <div>
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">UserName</th>
              <th scope="col">Employee Id</th>

              <th scope="col">Pattern After</th>
              
               <th scope="col">Password</th> 
            </tr>
          </thead>
          <tbody>{this.renderTableData()}</tbody>
        </table>
      </div>
    );
  }
}
