import React, { Component } from "react";
import "../../../node_modules/font-awesome/css/font-awesome.min.css";
import SearchRes from "./SearchRes";

class Search extends Component {
  state = {
    term: "",
    isLoading: false,
    received_value: []
  };
  handleChange = event => {
    this.setState({ term: event.target.value });
  };

  onSubmit = async event => {
    event.preventDefault();
    this.setState({ isLoading: true });
    const res_search = await fetch("http://localhost:4000/computerOps/search", {
      method: "post",
      header: {
        Accept: "application/json",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        term: this.state.term
      })
    });
    const json = await res_search.json();

    if (json.data.length === 0) {
      console.log(`${this.state.term} is not the user of CamDB_test database `);
    } else {
      console.log(json.data);
    }
    this.setState({ received_value: json.data });
    console.log(this.state.received_value);
    // await this.props.prData();
    // console.log(this.state.loading);
    this.setState({ isLoading: false });
  };
  render() {
    const { isLoading } = this.state;
    return (
      <div className="container">
        <form onSubmit={this.onSubmit} className="form-group">
          <div className="form-row align-items-center">
            <div className="col-sm-4">
              <label className="sr-only" htmlFor="Search"></label>
              <div className="input-group">
                <div className="input-group-prepend">
                  <div className="input-group-text mt-3 mb-5 ">Search</div>
                  <input
                    type="text"
                    id="Search"
                    value={this.state.term}
                    onChange={this.handleChange}
                    placeholder="User Name"
                    className="form-control mt-3 mb-5"
                    name="Search"
                  ></input>
                </div>
              </div>
            </div>
            <div className="col-sm-4 ">
              <select className="custom-select mr-sm-2 mt-3 mb-5">
                <option selected>Choose..</option>
                <option value="1">CamDB_test</option>
              </select>
            </div>
          </div>
          <button
            type="submit"
            onClick={this.onSubmit}
            className="btn btn-large btn-block btn-primary mt-5"
            id="butn"
            disabled={isLoading}
          >
            {isLoading && <i className="fa fa-refresh fa-spin" />}
            {isLoading && <span>Please wait Looking into the database</span>}
            {!isLoading && <span>Find</span>}
          </button>
        </form>
        <SearchRes val={this.state.received_value} />
      </div>
    );
  }
}

export default Search;
