import React, { Component } from "react";
import "./Nab.css";
import background from "../Image/Key.jpg";

class MainSection extends Component {
  render() {
    return (
      <section id="explore-section" class="bg-light text-muted">
        <div className="container main">
          <h2 className="head mb-5">Centeralized Access Management</h2>
          <div className="row">
            <div className="col-md-6">
              <img
                src={background}
                alt="hello"
                id="image-section"
                class="img-fluid mb-3 rounded-circle"
              />
            </div>
            <div className="col-md-6 text-center">
              <h3>Explore & Connect</h3>
              <p>
              Centeralized Access Management enables you to manage and provide access for all the domain at one place.
              </p>
            </div>
          </div>
        </div>
      </section>
    );
  }
}
export default MainSection;

             
             
