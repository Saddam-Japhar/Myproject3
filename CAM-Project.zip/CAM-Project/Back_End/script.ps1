Import-Module ActiveDirectory

function Get-RandomCharacters($length, $characters) { 
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length } 
    $private:ofs="" 
    return [String]$characters[$random]
}



$password = Get-RandomCharacters -length 6 -characters 'abcdefghikmnoprstuvwxyz'
$password += Get-RandomCharacters -length 1 -characters 'ABCDEFGHKLMNOPRSTUVWXYZ'
$password += Get-RandomCharacters -length 1 -characters '23456789'
$password += Get-RandomCharacters -length 1 -characters '@#&$'


$data = ($password -split '' | Sort-Object {Get-Random}) -join ''




$OU = (Get-ADUser -Identity $args[3] -Properties distinguishedname,cn | select @{n='ParentContainer';e={$_.distinguishedname -replace '^.+?,(CN|OU.+)','$1'}}).ParentContainer

$upn = $args[2]+"@catmktg.com"

$full = $args[0]+" "+$args[1]

New-AdUser -SamAccountName $args[2] -GivenName $args[0]  -Name $full -Surname $args[1] -Path $OU -AccountPassword $(ConvertTo-SecureString $data �asplaintext �force) -UserPrincipalName $upn

$one = $args[6]
$two = $args[8]

$desc = "Created per #(Ref:IN:$one)_$($(Get-Date).ToString('MMddyy'))_$two"

#Set-AdUser $args[2] -ChangePasswordAtLogon $true -Enabled $true -employeeID $args[4] -Title $args[5] -Description $desc -DisplayName $args[7] 
Set-AdUser $args[2] -ChangePasswordAtLogon $true -Enabled $true -employeeID $args[4] -Title $args[5] -DisplayName $args[7] -Description $desc

Write-Host "$data"

