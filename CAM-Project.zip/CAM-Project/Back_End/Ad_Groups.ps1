﻿Import-Module ActiveDirectory


$groups = (Get-AdUser $args[0] -Properties Memberof).Memberof | Sort-Object

$actual = New-Object System.Collections.ArrayList;

$obj = new-object psobject

$grp_json = @()


foreach ($group in $groups)
{

    $temp = $group -replace "(CN=)(.*?),.*",'$2'
    $actual.Add($temp) | Out-Null
    
    $grp_json += New-Object -TypeName psobject -Property @{GroupName=$temp}
}


$grp_json | ConvertTo-Json